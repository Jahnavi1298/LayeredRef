package com.paytm.dao;

import java.util.Collection;
import java.util.HashMap;

import com.paytm.bean.Paytm;
import com.paytm.service.PaytmServiceImpl;

public class PaytmDaoImpl implements IPaytmDao {
	static HashMap<Integer,Paytm> Trlist= new HashMap<Integer,Paytm>();
	Paytm re=null;
	@Override
	public int Addtransaction(Paytm e) {
		 Trlist.put(e.getRcId(),e);
		 Trlist.put(e.getRcId(),e);
		 System.out.println(Trlist.values());
		 
			  return e.getRcId() ;
	}

	@Override
	public void viewAllTransactions() {
		System.out.println("Transactions are:");
		for(Paytm e:Trlist.values()){
		 
			System.out.println("Transaction id:"+e.getRcId());
			System.out.println("Customer ename:"+e.getName());
			System.out.println("Mobile num"+e.getMobileNum());
			System.out.println("Type of Recharge:"+e.getRechargeType());
			System.out.println("Plan for recharge:"+e.getPlanName());
			System.out.println("Description"+e.getDescription());
			System.out.println("Balance"+e.getBalance());
			
			
		}
	}

	@Override
	public void viewById(int id) {
		re=new Paytm();
		 re=Trlist.get(id);
		System.out.println("Transaction id:"+re.getRcId());
		System.out.println("Customer ename:"+re.getName());
		System.out.println("Mobile num"+re.getMobileNum());
		System.out.println("Type of Recharge:"+re.getRechargeType());
		System.out.println("Plan for recharge:"+re.getPlanName());
		System.out.println("Description"+re.getDescription());
		System.out.println("Balance"+re.getBalance());
		 
	}

	@Override
	public void deleteById(int id) {
		 
		Trlist.remove(id);
		System.out.println(Trlist.keySet());
	}

	@Override
	public boolean updateDescription(int id,String description) {
    Paytm e=Trlist.get(id);
		if(e!=null){
			e.setDescription(description);
			return true;
		}
		return false;
	}
		
	}


