package com.cg.mm.exception;

public class PMSException extends Exception {

	public PMSException(String message) {
		
		super(message);
		
	}

	
	
	
}
