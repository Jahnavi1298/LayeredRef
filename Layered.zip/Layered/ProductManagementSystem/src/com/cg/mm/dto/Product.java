package com.cg.mm.dto;

public class Product {
	
	private Integer id;
	private String name;
	private Integer cost;
	private String group;
	
	
	public Product() {
		
	}


	public Product(Integer id, String name, Integer cost, String group) {
		
		this.id = id;
		this.name = name;
		this.cost = cost;
		this.group = group;
	}

	
	
	

	public Product(String name, Integer cost, String group) {
		
		this.name = name;
		this.cost = cost;
		this.group = group;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Integer getCost() {
		return cost;
	}


	public void setCost(Integer cost) {
		this.cost = cost;
	}


	public String getGroup() {
		return group;
	}


	public void setGroup(String group) {
		this.group = group;
	}


	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", cost=" + cost + ", group=" + group + "]\n";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
