package MobileService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Scanner;

import MobileBeans.CustomerBeans;
import MobileBeans.MobileBean;
import MobileBeans.Reciept;
import MobileDao.MobileDaoClass;

public class MobileServiceClass {
	
	MobileDaoClass MD=new MobileDaoClass();
	MobileBean MB=new MobileBean();
	CustomerBeans CB=new CustomerBeans();

	Reciept rp=new Reciept();
	
	public void purchaseMobile()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Your Name");
		String name=sc.next();
		
		System.out.println("Enter Address Address");
		String addrs=sc.next();
		
		System.out.println("Enter Your Mob No");
		String mobno=sc.next();
		
		System.out.println("Choose Your Mobile Model");
		MD.displayMobiles();
		
		
		
		System.out.println("Enter your Model No");
		int n=sc.nextInt();
		rp.setOrderId(12345);
	 MB = MD.GetMobiledetail(n);
		
		System.out.println("You Have Successfully Purchased "+MB.getMobileName()+" Mobile And Generated ID Is "+rp.getOrderId());
		
		
		CB.setCustomerName(name);
			CB.setCustAddrs(addrs);
		CB.setCustMoNo(mobno);
				
				rp.setCustomerName(CB.getCustomerName());
				rp.setCustAddrs(CB.getCustAddrs());
				rp.setCustMoNo(CB.getCustMoNo());
				rp.setCustId(101);
				
				rp.setMobileName(MB.getMobileName());;
				rp.setMobileModel(MB.getMobileModel());
				rp.setMobileprice(MB.getMobileprice());
				
				Date date=new Date();
				SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
				String strdate=sd.format(date);
				
				rp.setPurchasedate(strdate);
				rp.setPricewithgst(MB.getMobileprice() + (MB.getMobileprice() * 0.05f));
		
				MD.storeIntoDao(rp);
		
		
	}

	public Reciept getOrderdetails(int orderid) {
		
		Reciept rpc=MD.getFromDao(orderid);
		return rpc;
		
		
		
	}

}
