package MobileDao;

public interface MobileDaoInterface {

}
