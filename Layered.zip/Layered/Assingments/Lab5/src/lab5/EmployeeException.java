package lab5;

import java.util.Scanner;

public class EmployeeException extends Exception 
{
	public EmployeeException(String string) {
		// TODO Auto-generated constructor stub
	}


	 ExceptionEmployee(String a){
		System.out.println("Exception="+a);
	}
	
	
public static void main(String[] arg) {
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the salary");
	int salary=sc.nextInt();
	try
	{
	if(salary<3000)
	{
		throw new EmployeeException("low");
	}
		else
			System.out.println("salary is high");
	}
			
		catch(Exception d)
		{
		}
}
}

