package lab1;

import java.util.Scanner;

public class Excercise3 {
	public  boolean CheckNumber(int number)
	{
		if(number==0) {
			return false;
			
		}
		
		while(number!=1)
		{
			if(number%2!=0)
			{
				return false;
			}
				number=number/2;
				return true;
			}
		return false;
		
				
		}
	public static void main(String[] arg)
	{ 
		Excercise3 e=new Excercise3();
		Scanner s=new Scanner(System.in);
		int number= s.nextInt();
		boolean ss= e.CheckNumber(number);
		System.out.println(ss);
	}	
	}
	

