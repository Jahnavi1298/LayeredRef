package demo;

public class StringClassDemo {
	public static void main(String args[]) {
		String s=new String("Hello Everybody");
		System.out.println("Length:"+s.length());
		System.out.println("char at 0th pos:"+s.charAt(0));
		System.out.println("uppercase;"+s.toUpperCase());
		String sOb=s.toLowerCase();
		System.out.println("lowercase:"+s.toLowerCase());
		char sArr[]=s.toCharArray();
		for(char c:sArr)
			System.out.println(c+" ");
		System.out.println();
		String str="welcome to java";
		String strArr[]=str.split(" ");
		for(String sFor:strArr)
			System.out.println(sFor+":");
		System.out.println();
		String s1="Hello";
		String s2="hello";
		if(s1.equals(s2))
			System.out.println("true");
		else
			System.out.println("false");
		System.out.println();
		if(s1.equalsIgnoreCase(s2))
			System.out.println("true");
		else
			System.out.println("false");
	}

}
