package demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ToArrayCollectionDemo {
	public static void main(String args[]) {
		List<Integer> numberList =new ArrayList<Integer>();
		numberList.add(118);
		numberList.add(23);
		numberList.add(13);
		numberList.add(434);
	Stream<Integer> s=numberList.stream();
	Integer intArr[]=s.toArray(Integer[]::new);
	
	
	// or//
	
	//Integer intArr[]=numberList.stream().toArray(Integer[]::new);
	for(Integer i:intArr)
		System.out.println(i);
	
	System.out.println();
	Stream<Integer> sof=Stream.of(intArr);
	sof.forEach(System.out::println);
	
	//or//
	
	//Stream.of(intArr).forEach(System.out::println);//arraytostream
	}

}
