package demo;

import java.util.Arrays;
import java.util.stream.*;

public class StreamDemo {
public static void main(String args[]) {
	Integer a[]= {1,2,3,4,5};
	Stream<Integer> s=Arrays.stream(a);
	s.forEach(System.out::println);//Method Referencing
}
} 
