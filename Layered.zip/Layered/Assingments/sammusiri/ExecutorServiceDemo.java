package demo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorServiceDemo {
	public static void main(String args[]) {
	//	ExecutorService ec1=Executors.newSingleThreadExecutor();
		ExecutorService ec2=Executors.newFixedThreadPool(8);
		ec2.execute(new MusicPlayTask());
		ec2.execute(new CopyTask());
		ec2.shutdown();
		
	}

}
