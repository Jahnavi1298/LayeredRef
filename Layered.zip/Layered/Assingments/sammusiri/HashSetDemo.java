package demo;
import java.util.*;
public class HashSetDemo {
public static void main(String args[]) {
	HashSet hs=new HashSet();
	Integer iObj=5;
	hs.add(iObj);
	hs.add(1);
	hs.add(1);
	hs.add(1.2);
	hs.add("hello");
	hs.add(8.6);
	System.out.println(hs);
	Iterator i=hs.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
	
}
}
