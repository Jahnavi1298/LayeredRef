package demo;

public class ThreadSleepDemo implements Runnable{
	ThreadSleepDemo(String name){
		Thread t=new Thread(this,name);
		t.start();
	}
public void run() {
	System.out.println(Thread.currentThread().getName()+"is running");
	while(true) {
		try {
	//Thread.sleep(6000);
	System.out.println(Thread.currentThread().getName()+"is alive");
	Thread.sleep(6000);
	System.out.println(Thread.currentThread().getName()+"resumed");
}
		catch(InterruptedException e) {
			System.out.println(e);
		}
}
}
public static void main(String args[]) {
	ThreadSleepDemo tobj1=new ThreadSleepDemo("Thread 1");
	ThreadSleepDemo tobj2=new ThreadSleepDemo("Thread 2");
	
}
}