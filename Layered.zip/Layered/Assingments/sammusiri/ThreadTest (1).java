package demo;
class HelloThread implements Runnable{
	public void run() {
		//System.out.println("Run Start");
		
			for(int i=0;i<10;i++) {
			System.out.println("Run Start");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		
	}
}
public class ThreadTest {
	public static void main(String args[]) {
		HelloThread ht=new HelloThread();
		Thread t=new Thread(ht);
		t.start();
	}

}
