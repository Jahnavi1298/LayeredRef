package demo;

import java.util.Scanner;
import java.util.StringTokenizer;

public class StringTokenizerDemo {
	public static void main(String args[]) {
		System.out.print("Enter a String:");
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		StringTokenizer st=new StringTokenizer(str);
		while(st.hasMoreElements()) {
			System.out.println(st.nextElement());
		}
		sc.close();
	}

}
