package demo;
import java.util.*;
public class TreeSetDemo {
public static void main(String args[]) {
	TreeSet ts=new TreeSet();
	ts.add(1);
	ts.add(43);
	ts.add(32);
	ts.add(5);
	ts.add(9);
	ts.add(123);
	ts.add(23);
	//ts.add("hello");//exception will be raised
	System.out.println(ts);
}
}
