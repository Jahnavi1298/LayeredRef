package demo;

import java.time.LocalDate;
import java.util.Calendar;

public class CalendarDemo {
	public static void main(String args[])
	{
		//old way
		Calendar c=Calendar.getInstance();
		System.out.println("The current Date is:"+c.getTime());
		System.out.println("The current Calendars year:"+c.get(Calendar.YEAR));
		System.out.println("The current calendars month:"+c.get(Calendar.MONTH));
		System.out.println("The currentcalendars day:"+c.get(Calendar.DAY_OF_MONTH));
		System.out.println("The current Minute:"+c.get(Calendar.MINUTE));
		System.out.println("The current Second:"+c.get(Calendar.SECOND));
		
		//jdk 8
		System.out.println();
		LocalDate currentDate=LocalDate.now();
		System.out.println("The day of week:"+currentDate.getDayOfWeek());
		System.out.println("The day of month:"+currentDate.getDayOfMonth());
		System.out.println("The day of the year:"+currentDate.getDayOfYear());
		System.out.println("month:"+currentDate.getMonth());
		System.out.println("year:"+currentDate.getYear());

	}

}
