package demo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringPatternMatchDemo2 {
	public static void main(String args[]) {
		String input1="ho";
		String input="shopping,hopping,mop,choppin";
		Pattern pattern=Pattern.compile("ho");
		//Matcher matcher1=pattern.matcher(input1);
		Matcher matcherObj=pattern.matcher(input);
		//System.out.println(matcher.matches());
		while(matcherObj.find()) {
			System.out.println(matcherObj.group()+":"+matcherObj.start()+":"+matcherObj.end());
		}
	}

}
