package demo;

public class finallydemo {
	public static void main(String args[]) {
		try {
			int i=10/0;
			System.out.println("after try block");
		}catch(ArithmeticException ae) {
		System.out.println("Exception raised");
	}
		finally {
			System.out.println("finally");
		}
	System.out.println("reamaining block of code");
}

}
