package demo;
class Student{
	int regNo;
	String stuName;
	Student(int rNo,String name){
		regNo=rNo;
		stuName=name;
	}
	void displayStudentDetails() {
		System.out.println("regno "+regNo+ " name "+stuName);
	}
}
public class ArrayDemo5 {
	public static void main(String args[]) {
		Student []obj=new Student[2];
		obj[0]=new Student(1,"rose");
		obj[1]=new Student(2,"vachu");
		for(Student i:obj)
			i.displayStudentDetails();
		
		Student st1=new Student(3,"kavi");//otherway
		Student st2=new Student(4,"balaji");
		Student obj1[]=new Student[2];
		obj1[0]=st1;
		obj1[1]=st2;
		for(Student j:obj1)
			j.displayStudentDetails();
		
	}
}
