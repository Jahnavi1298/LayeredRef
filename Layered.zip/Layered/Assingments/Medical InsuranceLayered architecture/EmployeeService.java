package com.cg.eis.service;
import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmpDao;;
public class EmployeeService
{
	EmpDao dao = new EmpDao();
		public void addService(Employee Obj)
		
		{
			Employee obj1 = storeInService(Obj);
			dao.StoreData(obj1);
			
		}
		
public void RetrieveService(Employee Obj1)
{
	dao.RetrieveData(Obj1);
}
public Employee storeInService(Employee obj) 
{
	
	float sal = obj.getSalary();
	String designation = obj.getDesignation();
	
	if(sal>5000 && sal<20000 && designation.equals("System_Associate") || designation.equals("system_associate") )
	{
		obj.setInsuranceScheme("Scheme C");
	}
	else if(sal>=20000 && sal<40000 && designation.equals("Programmer") || designation.equals("programmer"))
	{
		obj.setInsuranceScheme("Scheme B");
	}
	else if(sal>=40000 && designation.equals("Manager")|| designation.equals("manager"))
	{
		obj.setInsuranceScheme("Scheme A");
		
	}
	else if(sal<5000 && designation.equals("Clerk") || designation.equals("clerk"))
	{
		obj.setInsuranceScheme("No Scheme");
	}
	else {
		System.out.println("Invalid");
	}
	   return obj;
}
}