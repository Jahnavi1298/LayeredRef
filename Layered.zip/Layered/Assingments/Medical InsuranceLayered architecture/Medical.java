package com.cg.eis.service;

public interface Medical 
{
	public void storeInService();
}
