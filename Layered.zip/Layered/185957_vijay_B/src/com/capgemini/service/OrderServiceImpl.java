package com.capgemini.service;

import com.capgemini.dao.OrderDao;
import com.capgemini.dao.OrderDaoImpl;
import com.capgemini.model.Product;

public class OrderServiceImpl implements OrderService {
	private OrderDao dao = new OrderDaoImpl();
	@Override
	public int calculateOrder(Product p) {
		p.setCurrencyCC((((p.getPrice()*75)*1.25)/100));
		p.setPrice(p.getCurrencyCC()+(p.getPrice()*75));
		p.setPrice(p.getPrice()*p.getQuantity());
		return dao.saveOrder(p);
	}

}