package com.cg.empapp.exception;

public class EmployeeException extends Exception 
{

	

	
}
