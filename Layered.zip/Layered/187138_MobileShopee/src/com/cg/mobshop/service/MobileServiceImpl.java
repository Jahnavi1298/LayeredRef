package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl implements MobileService {

	MobileDAO dao=new MobileDAOImpl();
	
	@Override
	public List<Mobiles> getAllMobiles() {

		return dao.getAllMobiles();
	}

	@Override
	public boolean deleteMobile(int mobileId) {

		boolean status=dao.deleteMobile(mobileId);
		if(status=true) {
			
			status=true;
		}
		
		
		return status;	}

	
	
}
