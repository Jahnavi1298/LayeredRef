package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileService {

	List<Mobiles> getAllMobiles();

	boolean deleteMobile(int mobileId);


}
