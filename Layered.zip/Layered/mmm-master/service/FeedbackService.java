package com.capgemini.fms.service;

import java.util.Map;

import com.capgemini.fms.dao.FeedbackDAO;

public class FeedbackService implements IFeedbackService{
	FeedbackDAO dao=new FeedbackDAO();
	Validate validator=new Validate();
	
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			validator.validateData(name, rating, subject);//validating the given data
			return dao.addFeedbackDetails(name, rating, subject);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return dao.getFeedbackReport();
	}

}
