package com.cg.tms.exception;

@SuppressWarnings("serial")
public class myException extends Exception{
	public myException(){
		super("Ticket status is empty");
	}
}
