package com.cg.tms.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.myException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {
		TicketService service=new TicketServiceImpl();
		Scanner scan=new Scanner(System.in);
		int choice;
		List<TicketCategory> listCategory=new ArrayList();
		while(true) {
			System.out.println("Welcome to ITIMD Help Desk");// displaying the menu
			System.out.println("Menu:\n1. Raise a Ticket\n2.Exit from the system");
			choice=scan.nextInt();
			switch(choice) {
			case 1:
				try {
					TicketBean ticketBean=new TicketBean();
					TicketCategory ticketCategory=new TicketCategory();
					listCategory=service.listTicketCategory();//getting the category list from the DAO implementation
					Iterator i=listCategory.iterator();
					int index=1;
					System.out.println("Select a Category");//picking a category from the given list
					while(i.hasNext()) 
					{
						TicketCategory ticket=new TicketCategory();
						ticket=(TicketCategory) i.next();
						System.out.println(+index+":"+ticket.getCategoryName());
						index=index+1;
					}
					int category=scan.nextInt();
					ticketCategory=listCategory.get(category-1);
					ticketBean.setTicketCategory(ticketCategory);
					System.out.println("Enter priority(1. low 2. medium 3. high)");//entering the priority
					int priority=scan.nextInt();
					if(priority==1)
					{
						ticketBean.setTicketPriority("low");
					}
					else if(priority==2)
					{
						ticketBean.setTicketPriority("medium");
					}
					else if(priority==3)
					{
						ticketBean.setTicketPriority("high");
					}
					else
					{
					System.out.println("enter a valid priority number(1. low 2. medium 3. high)");
					}
					ticketBean.setTicketStatus("new");//setting the ticket status to new
					System.out.println("Enter Description related to issue");//entering the description
					ticketBean.setTicketDescription(scan.next());
					scan.nextLine();
					int number=service.raiseNewTicket(ticketBean);
					Date date=new Date(System.currentTimeMillis());
					System.out.println("TicketNumber "+number+" logged successfully at "+date);//displayin the generated ticket number and current system time
				}
				catch(myException e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				scan.close();
				System.exit(0);
			default:
				System.out.println("Enter a valid option");
				break;
				
			}
		}
	}
}
