package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.myException;

public class TicketDAOImpl implements TicketDAO {
	private static Map<String, String> ticketCategory=new HashMap<String, String>();
	private static Map<Integer, TicketBean> ticketLog=new HashMap<Integer, TicketBean>();
	@Override
	public int raiseNewTicket(TicketBean ticketBean) throws myException {
		// TODO Auto-generated method stub
		try {
			if(ticketBean.getTicketStatus().isEmpty())
			{
				throw new myException();
			}
		Random rand=new Random();
		int randomNum=rand.nextInt(5000)+2000;//generating a random number between 2000-5000
		String generatedNum=Integer.toString(randomNum);
		ticketBean.setTicketNo(generatedNum);
		ticketLog.put(randomNum, ticketBean);
		return randomNum;
		}
		catch (myException e)
		{
			throw e;
		}
	}

	public Map<String, String> getTicketCategoryEntries() {
		// TODO Auto-generated method stub
		ticketCategory.clear();//clearing the category map
		ticketCategory.put("tc001", "Software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailboc issues");
		return ticketCategory;
	}
	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		List<TicketCategory> listCategory=new ArrayList<TicketCategory>();
		Map<String, String> ticketCategory=new HashMap<String, String>();
		ticketCategory=getTicketCategoryEntries();
		Set<Entry<String, String>> set=ticketCategory.entrySet();
		Iterator<Entry<String, String>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, String> me=(Map.Entry<String, String>)i.next();
			TicketCategory ticket=new TicketCategory();
			ticket.setTicketCategoryId(me.getKey());
			ticket.setCategoryName(me.getValue());
			listCategory.add(ticket);
		}
		return listCategory;
	}

}
