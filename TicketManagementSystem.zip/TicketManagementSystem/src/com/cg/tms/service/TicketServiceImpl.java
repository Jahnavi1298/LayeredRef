package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.myException;

public class TicketServiceImpl implements TicketService {
	TicketDAO dao=new TicketDAOImpl();
	@Override
	public int raiseNewTicket(TicketBean ticketBean) throws myException {
		// TODO Auto-generated method stub
		try {
			return dao.raiseNewTicket(ticketBean);
		}
		catch(myException e)
		{
			throw e;
		}
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		return dao.listTicketCategory();
	}

}
