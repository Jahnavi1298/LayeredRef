package com.cg.tms.testcase;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.myException;

class RaiseTicket {

	@Test
	@DisplayName("raise a ticket functionality")
	void test() {
		TicketDAO dao=new TicketDAOImpl();
		TicketBean ticketBean=new TicketBean();
		TicketCategory ticketCategory=new TicketCategory();
		ticketCategory.setTicketCategoryId("tc001");//adding some details to the ticket
		ticketCategory.setCategoryName("Software Installation");
		ticketBean.setTicketCategory(ticketCategory);
		ticketBean.setTicketDescription("New Eclipse software");
		ticketBean.setTicketPriority("High");
		ticketBean.setTicketStatus("new");
		int number = 0;
		try {
			number=dao.raiseNewTicket(ticketBean);//calling the dao method and assigning the number to variable 
		}
		catch(myException e)
		{
			System.out.println("error");
		}
		boolean condition= false;
		if(number>2000)//taking the condition that the ticket number must be greater than 2000
		{
			condition=true;
		}
		assertTrue(condition);
	}

}
