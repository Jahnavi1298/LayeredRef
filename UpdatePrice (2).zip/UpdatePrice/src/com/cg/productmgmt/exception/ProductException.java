package com.cg.productmgmt.exception;

public class ProductException extends Exception{
	public ProductException(String arg){
		System.out.println(arg);
		
	}
	public ProductException() {
		
	}
	
	
}
