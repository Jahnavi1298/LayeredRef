package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client 
{
	
    /**
        Refer the sample input and output for the presentation layer messages
        Do not use tab or extra newline, which will lead to presentation error.
        Do not provide any additional messages, which is not asked for
    */
    public static void main(String [] args){
    	ProductService serviceobj=new ProductService();
    	int ch;
		char choice;
        Scanner sc=new Scanner(System.in);
    	do {
    		System.out.println(" 1)Update Product Price\n 2)Exit\n ");
    				System.out.print("Enter your choice : ");
    				ch = sc.nextInt();
    				switch(ch) {
    				case 1:
    					String category;
    					try {
							do {
                  System.out.println("Enter the Product Category :"); 
							category=sc.next();
							}while(!serviceobj.isCategoryValid(category));
						
                      
                       int hike;
                       do {
                    	  
                    	   System.out.println("Enter hike Rate :");
                    	  hike=sc.nextInt();
           				
           			 	}while(!serviceobj.isHikeValid(hike)); 
           			serviceobj.updateProducts(category, hike);
           	
                           break;
    					 } catch (ProductException e) {
    							
    							e.printStackTrace();
    						}
    					continue;
    					
    		
    				 	  
    				
	            			
    	             case 2:
    	           	   	System.out.println("END");
    	           	   	return;
    	           	   	
    	             default:
         	            
 	            		System.out.println("Enter correct choice");
 	            		System.out.println(" 1)Update Product Price\n 2)Exit\n ");
 	            			System.out.print("Enter your choice : ");
 	            			ch = sc.nextInt();
 	            			continue;
					
    	            			
    	           	}
    				System.out.print("Do you want to continue (y/n)...? : ");
    				choice = sc.next().charAt(0);
    				if(choice == 'y' || choice=='Y')
    					continue;
    				else {
    					System.out.println("Thank You !");
    					System.exit(0);
    				}
    		}while(ch!=3);
    
    			sc.close();

        
    }
}