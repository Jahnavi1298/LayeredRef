package com.cg.productmgmt.service;



import java.util.Map;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService
{
ProductDAO daoobj=new ProductDAO();
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
	
		        
		         daoobj.updateProducts(Category,hike);
		         return 0;
		    			
		    			
		        		
		        			       
				        		     
				
		
	
	}

	@Override
	public Map<String, Integer> getProductDetails() {
		daoobj.getProductDetails();
		return null;
	}
	
	
	//method to validate Hike
	public boolean isHikeValid(int hike) {
		boolean b= false;
		if(hike>0)
		
			b=true;
		else {
			 System.out.println("Hike rate should be greater than zero");
			 return b;
		}
		return b;
	
		
	}
	//method to validate Cateogry
	public boolean isCategoryValid(String category) throws ProductException {
		
		boolean hm=daoobj.isCategoryValid(category);
		
		return hm;
		
	}
	

 
}