package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;


public class ProductDAO implements IProductDAO
{
 
	
	//map for ProductName as key and Category as value
	
		public static Map<String,String> productDetails;	
		
		//map for Product name as key  and price as value value
		
		public static Map<String,Integer> salesDetails;		

		
		//Getter and Setter
		
		public static Map<String, Integer> getSalesDetails() {
			return salesDetails;
		}

		public static void setSalesDetails(Map<String, Integer> salesDetails) {
			ProductDAO.salesDetails = salesDetails;
		}

		public static void setProductDetails(Map<String, String> productDetails) {
			ProductDAO.productDetails = productDetails;
		}
		
		  static {

	             productDetails= new HashMap<>();

	             productDetails.put("lux","soap");

	            productDetails.put("colgate","paste");

	           productDetails.put("pears","soap");

	           productDetails.put("sony","electronics");

	          productDetails.put("samsung","electronics");

	         productDetails.put("facepack", "cosmatics");

	         productDetails.put("facecream", "cosmatics");


	         salesDetails= new HashMap<>();

	         salesDetails.put("lux", 100);

	         salesDetails.put("colgate", 50);

	         salesDetails.put("pears", 70);

	         salesDetails.put("sony", 10000);

	         salesDetails.put("samsung", 23000);

	         salesDetails.put("facepack", 100);

	         salesDetails.put("facecream", 60);  


	}
		//implement methods in the interface
		
		@Override
		public int updateProducts(String Category, int hike) throws ProductException {
			
		
			if( productDetails.containsValue(Category)) {
				if( productDetails.containsValue(Category)==salesDetails.containsKey(Category))
        		for(int value: salesDetails.values())
    			{
    				int percentage=(value*hike)/100;
    				System.out.println(" "+percentage);
    			}
			}
        		else {
        			throw new ProductException();
        		}
			return 0;
		
			
		
		
			
		}
		@Override
		public Map<String, Integer> getProductDetails() {

    		Set keys=salesDetails.keySet();
    		Iterator itr=keys.iterator();
    		String key;
    		int value;
    		while(itr.hasNext())
    		{
    			key= (String) itr.next();
    			value=salesDetails.get(key);
    			System.out.println(key+":"+value);
    		}
			
			
			return salesDetails;
		}
		public boolean isCategoryValid(String category) throws ProductException{
			boolean b=false;
			if(productDetails.containsValue(category))
			{
				b=true;
			}
			else {
				throw new ProductException("Category not found");
			}
			
			return b;
			
		}
	
}


