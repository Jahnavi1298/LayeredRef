package com.cg.empapp.ui;

import java.util.Scanner;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.service.EmployeeServiceImpl;

public class Client {
	
	static EmployeeServiceImpl se=new EmployeeServiceImpl();
	public static void main(String[] args)  {
		
		int ch;
		int choice;
		Scanner s=new Scanner(System.in);
		do
		{
			System.out.println("1.AddEmployee\n"
			 		+ " 2.Get AllEmployee Details\n"
			 		+ " 3.Get Employee byId\n"
			 		+ " 4.EXIT");
			System.out.println("Enter your choice:");
		    ch=s.nextInt();
		    switch(ch)
		    {
		    case 1:
		    	System.out.println("empId:");
		    	int id=s.nextInt();
		    	System.out.println("empName:");
		    	String name=s.next();
		    	se.isEmpNameValid(name);
		    	System.out.println("empSal:");
		    	int sal=s.nextInt();
		    	se.isEmpSalValid(sal);
		    	Employee emp=new Employee(id,name,sal);
		    	se.insertEmployee(emp);
		    	System.out.println("Employee Information stored successfully for" + id);
		    	break;
		    case 2:
		    	try {
					se.getAllEmployees();
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	break;
		    case 3:
		    	System.out.println("EnterId:");
		    	int eid=s.nextInt();
		    	try {
					se.getEmployeeById(eid);
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	break;
		    case 4:
		    	System.out.println("END");
				System.exit(0);
				break;
		    default:
   			System.out.print("Enter your choice : ");        			
		}
		System.out.print("Do you want to continue (y/n)...? : ");
		 choice = s.next().charAt(0);
		if(choice == 'y' || choice=='Y')
			continue;
		
		else 
		{
			System.out.println("Thank You!");
			System.exit(0);
		}
}
		while(ch!=4);
	    s.close();
		    	
		    }
		    
		}
		
		



