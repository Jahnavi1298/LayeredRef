package com.cg.empapp.service;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.empapp.dao.EmployeeDaoImpl;
import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{
	//private static final Object character = null;
	Scanner s=new Scanner(System.in);
 EmployeeDaoImpl d=new  EmployeeDaoImpl();
 
 @Override
	public HashMap<Integer, Employee> getAllEmployees() throws EmployeeException {
		d.getAllEmployees();
		return null;
	}
	
	@Override
	public void insertEmployee(Employee emp) {
		 d.insertEmployee(emp);
		
	}
	
	@Override
	public Employee getEmployeeById(int eid) throws EmployeeException {
		Employee emp=d.getEmployeeById(eid);
		return emp;
	}
	
     public boolean isEmpSalValid(int sal) {
		while(true)
		{
			if(sal>0)
			{
				return true;
			}
			else
			{
				System.out.println( "Salary should be greater than zero");
				System.out.println("Enter a valid amount:");
				sal=s.nextInt();
			}
		}
		
	}

	public boolean isEmpNameValid(String name) {
		while(true)
		{
			
			if(name.length()>=3 && Character.isUpperCase(name.charAt(0)))
			{
				return true;
			}
			else
			{
				System.out.println("Invalid Name:");
				System.out.println("Enter your Name again:");
				name=s.next();
			}	
		}
		 
	}

	
	
}