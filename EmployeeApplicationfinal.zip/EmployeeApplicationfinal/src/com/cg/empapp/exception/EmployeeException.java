package com.cg.empapp.exception;

public class EmployeeException extends Exception 
{	
	public EmployeeException() {
		
	}
	public EmployeeException(String arg) {
		System.out.println(arg);
	}
}